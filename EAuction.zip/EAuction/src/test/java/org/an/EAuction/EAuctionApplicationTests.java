package org.an.EAuction;

//@SpringBootTest
class EAuctionApplicationTests {

	/*
	 * @Test void contextLoads() { }
	 */

}
