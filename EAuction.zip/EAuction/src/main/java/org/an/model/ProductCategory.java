package org.an.model;

public enum ProductCategory {

	PAINTING,SCULPTOR,ORNAMENT;
}
